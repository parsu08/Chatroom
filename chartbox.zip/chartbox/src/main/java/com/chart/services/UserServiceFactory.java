/**
 * 
 */
package com.chart.services;

/**
 * @author Parse
 *
 */
public class UserServiceFactory {
	
	public UserRegisterServiceImpl getUserServie(){
		return new UserRegisterServiceImpl();
	}

}
