package com.chart.services;

import com.chart.bo.User;

public interface UserRegisterService {
	public String createUser(User user);
}
