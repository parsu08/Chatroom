package com.chart.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chart.bo.User;
import com.chart.constant.ApplicationConstant;
import com.chart.dao.UserRegisterDao;
import com.chart.dto.ResponseDto;
import com.chart.utility.JsonUtil;
/**
 * 
 * @author Parse
 *
 */
@Service("userRegisterService")
public class UserRegisterServiceImpl implements UserRegisterService {

	
	
	@Autowired
	private UserRegisterDao userRegiteDao;
	private ResponseDto responseDto=null;
	public String createUser(User user) {
		responseDto=new ResponseDto();
		responseDto.setStatus(ApplicationConstant.FAILURE_STATUS);
		responseDto.setMsg("Registration failure ! please try again");
		if(user!=null){
			Boolean flag=userRegiteDao.createUser(user);
			if(flag){
				responseDto.setStatus(ApplicationConstant.SUCCESS_STATUS);
				responseDto.setMsg("Registration sucess");
				String jsonData=JsonUtil.convertJavaObjtoString(user);
				responseDto.setData(jsonData);
			}else{
				responseDto.setStatus(ApplicationConstant.FAILURE_STATUS);
				responseDto.setMsg("Registration failure ! please try again");
			}
			
			
			
		}
		
		
		return JsonUtil.convertJavaObjtoString(responseDto);
	}

}
