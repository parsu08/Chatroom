/**
 * 
 */
package com.chart.services;

import java.util.List;

import com.chart.bo.Comment;
import com.chart.bo.Message;

/**
 * @author Parse
 *
 */
public interface ChartService {
	public boolean saveMessage(Message msg);
	public List<Message> getMessage();
	public boolean saveComment(Comment commentOb);
	public List<Comment> getComment(int msgId);
}
