/**
 * 
 */
package com.chart.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chart.bo.Comment;
import com.chart.bo.Message;
import com.chart.dao.ChartDao;

/**
 * @author Parse
 *
 */
@Service
public class ChartServiceImpl implements ChartService{
	
	@Autowired
	private ChartDao chartDao;

	public boolean saveMessage(Message msg) {
		int count=0;
		boolean flag=false;
	if(msg!=null){
		count = chartDao.saveMessage(msg);
		if(count>0)
			flag=true;
		else 
			flag=false;
	}	
		return flag;
	}

	public List<Message> getMessage() {
		
		return chartDao.getMessage();
		
	}

	public boolean saveComment(Comment commentOb) {
		int count=0;
		boolean flag=false;
	if(commentOb!=null){
		count = chartDao.saveComment(commentOb);
		if(count>0)
			flag=true;
		else 
			flag=false;
	}	
		return flag;
	}

	public List<Comment> getComment(int msgId) {
		return chartDao.getComment(msgId);
		}
}
