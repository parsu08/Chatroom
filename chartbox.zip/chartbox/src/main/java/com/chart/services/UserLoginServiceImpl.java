/**
 * 
 */
package com.chart.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chart.bo.User;
import com.chart.constant.ApplicationConstant;
import com.chart.dao.UserLoginDao;

/**
 * @author Parse
 *
 */
@Service
public class UserLoginServiceImpl implements UserLoginService{
    @Autowired
	private UserLoginDao userLoginDao;
	
    User user=null;
	
    public User login(String uname, String password) {
		if(uname!=null && password!=null && uname.length() > 0 && password.length() > 0){
			user=userLoginDao.login(uname, password);
			//System.out.println(val);
			if(user!=null)
				return user;
			else
				return user;
		}else
		return user;
	}

}
