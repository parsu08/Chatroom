/**
 * 
 */
package com.chart.services;

import com.chart.bo.User;

/**
 * @author Parse
 *
 */
public interface UserLoginService {
	public User login(String uname,String password);
}
