/**
 * 
 */
package com.chart.dao;

import java.util.List;

import com.chart.bo.Comment;
import com.chart.bo.Message;

/**
 * @author Parse
 *
 */
public interface ChartDao {
	public int saveMessage(Message msg);
	public List<Message> getMessage();
	public int saveComment(Comment commentOb);
	public List<Comment> getComment(int msgId);

}
