/**
 * 
 */
package com.chart.dao;



import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.chart.bo.Comment;
import com.chart.bo.Message;
import com.chart.constant.SqlConstants;

/**
 * @author Balu
 *
 */
@Repository
public class ChartDaoImpl implements ChartDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	public int saveMessage(Message msg) {
		// TODO Auto-generated method stub
		Session ses=null;
		ses=sessionFactory.openSession();
		Transaction tx=null;
		boolean flag=false;
		int id=0;
		try{
			tx=ses.beginTransaction();
			id=(Integer)ses.save(msg);
			flag=true;
		}catch(HibernateException he){
			he.printStackTrace();
			flag=false;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			flag=false;
		}finally {
			if(flag){
				tx.commit();
			}else{
				tx.rollback();
			}
			ses.close();
				
		}
		return id;
	}

	public List<Message> getMessage() {
		Session ses=null;
		Criteria crMsg=null;
		ses=sessionFactory.openSession();
		crMsg=ses.createCriteria(Message.class);
		crMsg.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		List<Message> msg=crMsg.list();
		ses.close();
		return msg;
	}

	public int saveComment(Comment commentOb) {
		Session ses=null;
		ses=sessionFactory.openSession();
		Transaction tx=null;
		boolean flag=false;
		int id=0;
		try{
			tx=ses.beginTransaction();
			id=(Integer)ses.save(commentOb);
			flag=true;
		}catch(HibernateException he){
			he.printStackTrace();
			flag=false;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			flag=false;
		}finally {
			if(flag){
				tx.commit();
			}else{
				tx.rollback();
			}
			ses.close();
				
		}
		return id;
	}

	public List<Comment> getComment(int msgId) {
		Criteria comCr=null;
		Session ses=null;
		SQLQuery sqlQury=null;
		ses=sessionFactory.openSession();
		sqlQury=ses.createSQLQuery("select * from comment where msgId=?");
		sqlQury.setInteger(0,msgId);
		sqlQury.addEntity(Comment.class);
		//comCr=ses.createCriteria(Comment.class);
		//Criterion cond=Restrictions.eq("msgId", msgId);
		//comCr.add(cond);
		//List<Comment> comments=comCr.list();
		List<Comment> comments=sqlQury.list();
		return comments;
	}
	
	
}
