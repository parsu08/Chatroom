/**
 * 
 */
package com.chart.dao;

import com.chart.bo.User;

/**
 * @author Parse
 *
 */
public interface UserRegisterDao {
	
	public boolean createUser(User user);
	

}
