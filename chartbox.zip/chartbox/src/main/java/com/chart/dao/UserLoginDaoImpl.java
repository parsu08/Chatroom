package com.chart.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.chart.bo.User;

@Repository
public class UserLoginDaoImpl implements UserLoginDao {
	
	@Autowired
	private SessionFactory sessionFactory;

	public User login(String uname, String password) {
		User user=null;
		Session ses=null;
		Criteria cr=null;
		ses=sessionFactory.openSession();
		cr=ses.createCriteria(User.class);
		Criterion cond1=Restrictions.eq("email", uname);
		Criterion cond2=Restrictions.eq("password",password);
		Criterion finalCond=Restrictions.and(cond1, cond2);
		cr.add(finalCond);
		user=(User) cr.uniqueResult();
		ses.close();
		if(user!=null)
		return user;
		else
			return user;
	}

}
