package com.chart.dao;

import com.chart.bo.User;

public interface UserLoginDao {
	public User login(String uname,String password);
	
}
