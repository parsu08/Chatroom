/**
 * 
 */
package com.chart.dao;



import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.chart.bo.User;

/**
 * @author Parse
 *
 */
@Repository("userRegiteDao")
public class UserRegisterDaoImpl implements UserRegisterDao {

	
	@Autowired
	private SessionFactory sessionFactory;
	
	/* (non-Javadoc)
	 * @see com.chart.dao.UserRegisterDao#createUser(com.chart.bo.User)
	 */
	public boolean createUser(User user) {
		// TODO Auto-generated method stub
		
		Session ses=null;
		Transaction tx=null;
		boolean flag=false;
	     ses=sessionFactory.openSession();
	     try{
	    	 tx=ses.beginTransaction();
	    	 ses.save(user);
	    	 flag=true;
	     }catch(HibernateException he){
	    	 he.printStackTrace();
	    	 flag=false;
	     }catch (Exception e) {
			// TODO: handle exception
	    	 e.printStackTrace();
	    	 flag=false;
		}finally {
			ses.close();
			if(flag){
				tx.commit();
				return flag;
			}else{
				tx.rollback();
				return flag;
			}
			//ses.close();
		}
		//return flag;
	}

}
