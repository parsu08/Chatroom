package com.chart.dao;

public class UserDaoFactory {
	
	public UserRegisterDaoImpl getUserDao(){
		return new UserRegisterDaoImpl();
	}

}
