/**
 * 
 */
package com.chart.advice;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

/**
 * @author Parse
 *
 */
@Component
@Aspect
public class LoggingAdvice {

	
	@Pointcut("within(com.chart.services.*)")
	public void before(JoinPoint joinPoint){
		Logger logger=Logger.getLogger(joinPoint.getTarget().getClass());
		logger.info("Entered into"+joinPoint.getSignature().getName());
	}
	@Pointcut("within(com.chart.services.*)")
	public void myAfter(JoinPoint joinPoint,Object returnValue){
		Logger logger=Logger.getLogger(joinPoint.getTarget().getClass());
		logger.info("Execution completed :"+ joinPoint.getSignature().getName()+" :"+returnValue);
	}
	
}
