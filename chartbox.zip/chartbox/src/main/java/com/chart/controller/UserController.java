package com.chart.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.chart.bo.Message;
import com.chart.bo.User;
import com.chart.constant.ApplicationConstant;
import com.chart.services.ChartService;
import com.chart.services.UserLoginService;
import com.chart.services.UserRegisterService;

@Controller
public class UserController {
	
	@Autowired
	private UserRegisterService userRegisterService;
	
	@Autowired
	private UserLoginService userLoginService;
	
	@Autowired
	private ChartService chartService;
	
	/*Login controllers start*/
	
	@RequestMapping(value="/",method=RequestMethod.GET)
	public String loginForm(){
		return "login";
	}
	
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String loginAfterForm(){
		return "login";
	}
	
	@RequestMapping(value="userprofile",method=RequestMethod.GET)
	public ModelAndView userProfile(){
		List<Message> msgList=chartService.getMessage();
		//return new ModelAndView(new RedirectView("userprofile"),"msgList",msgList);
		return new ModelAndView("userprofile", "msgList", msgList);
	}
	
	
	
	@RequestMapping(value="login",method=RequestMethod.POST)
	public ModelAndView loginUser(HttpServletRequest req,@RequestParam("email") String email,@RequestParam("password") String password){
		User user=userLoginService.login(email, password);
		String status="Login Failure";
		if(user!=null){
			HttpSession ses=req.getSession();
			ses.setAttribute("email", email);
			ses.setAttribute("name", user.getName());
			List<Message> msgList=chartService.getMessage();
			//return new ModelAndView(new RedirectView("userprofile"),"msgList",msgList);
			return new ModelAndView("userprofile", "msgList", msgList);
		}
		else
			return new ModelAndView("login","msg",status);
	}
	
	/*Login controllers end*/
	
	/*Register controllers start*/
	
	@RequestMapping(value="register",method=RequestMethod.GET)
	public String registerForm(){
		return "regiterform";
	}
	
	@RequestMapping(value="createuser",method=RequestMethod.POST,produces="application/json")
	@ResponseBody
	public String createUser(@ModelAttribute User user){
		return userRegisterService.createUser(user);
		//return "regiterform";
	}
	
	/*Register controllers end*/

}
