/**
 * 
 */
package com.chart.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.chart.bo.Comment;
import com.chart.bo.Message;
import com.chart.bo.User;
import com.chart.services.ChartService;

/**
 * @author Parse
 *
 */
@Controller
public class ChartController {
	
	@Autowired
	private ChartService chartService;
	
	@RequestMapping(value="chart",method=RequestMethod.GET)
	public ModelAndView chartForm(){
		List<Message> msgList=chartService.getMessage();
		//return new ModelAndView(new RedirectView("userprofile"),"msgList",msgList);
		return new ModelAndView("Userchart", "msgList", msgList);
		//return "Userchart";
	}
	
	@RequestMapping(value="chart",method=RequestMethod.POST)
	public ModelAndView saveChart(HttpServletRequest req){
		HttpSession ses=req.getSession(false);
		Message chmsg=null;
		User user=null;
		String msg=req.getParameter("msg");
		String grName=req.getParameter("grname");
		System.out.println(ses.getAttribute("email")+" ses "+msg);
		String status="Message failure";
		if(msg!=null && msg.length()>0 && grName!=null && grName.length()>0){
			chmsg=new Message();
			user=new User();
			user.setEmail(ses.getAttribute("email").toString());
			chmsg.setMessage(msg);
			chmsg.setChartGroupName(grName);
			chmsg.setDtSub(new Date());
			chmsg.setUser(user);
			boolean flag=chartService.saveMessage(chmsg);
			if(flag){
				status="Message Success";
				//return new ModelAndView("Userchart","status",status);
			}
		}
		
		return new ModelAndView("Userchart","status",status);
		
	}
	
	@RequestMapping(value="joincomment",method=RequestMethod.GET)
	public ModelAndView joinComment(@RequestParam("msgId") String msgId,@RequestParam("msgDesc") String msgDesc){
	    ModelAndView modelAndView=null;
		Message msg=new Message();
		msg.setMsgId(Integer.parseInt(msgId));
		msg.setMessage(msgDesc);
		System.out.println(msgId+" "+Integer.parseInt(msgId));
		List<Comment> comments=chartService.getComment(Integer.parseInt(msgId));
		modelAndView=new ModelAndView();
		//return new ModelAndView("joincomment", "msg", msg);
		modelAndView.setViewName("joincomment");
		modelAndView.addObject("msg", msg);
		modelAndView.addObject("comments", comments);
		return modelAndView;
		
	}
	

	@RequestMapping(value="comment",method=RequestMethod.POST)
	public ModelAndView saveComment(HttpServletRequest req){
		HttpSession ses=req.getSession(false);
		Comment commentOb=null;
		Message msgOb=null;
		User user=null;
		String msgid=req.getParameter("msgid");
		String msg=req.getParameter("msg");
		String comment=req.getParameter("comment");
		String status="Message failure";
		if(comment!=null && comment.length()>0){
			commentOb=new Comment();
			user=new User();
			msgOb=new Message();
			user.setEmail(ses.getAttribute("email").toString());
			msgOb.setMsgId(Integer.parseInt(msgid));
			commentOb.setCoomment(comment);
			commentOb.setDtSub(new Date());
			commentOb.setSourceMessage(msgOb);
			commentOb.setUser(user);
			//commentOb.set
			boolean flag=chartService.saveComment(commentOb);
			if(flag){
				status="Message Success";
				return new ModelAndView("joincomment","status",status);
			}
		}
		return new ModelAndView("joincomment","status",status);
	}
}