/**
 * 
 */
package com.chart.utility;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Parse
 *
 */
public class JsonUtil {
	
	private static ObjectMapper mapper;
	static{
		mapper=new ObjectMapper();
	}
	
	/**
	 * 
	 * @param Obj
	 * @return String
	 */
	public static String convertJavaObjtoString(Object Obj){
		String json=null;
		try {
			json = mapper.writeValueAsString(Obj);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return json;
	}
	
	public static <T>T convertStringToObj(String json,Class<T> jsonclass){
		T response=null;
		try {
			response=mapper.readValue(json, jsonclass);
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return response;
	}
	

}
