/**
 * 
 */
package com.chart.constant;

/**
 * @author Parse
 *
 */
public class SqlConstants {
	public static final String GET_COMMENTS="select * from comment";
}
