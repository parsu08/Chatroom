package com.chart.constant;

/**
 * 
 * @author Parse
 *
 */
public class ApplicationConstant {
	
	public static final String SUCCESS_STATUS="SUCCESS";
	public static final String FAILURE_STATUS="FAILURE";

}
