/**
 * 
 */
package com.chart.bo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author Parse
 *
 */
@Entity
@Table(name="COMMENT")
public class Comment implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer commentId;
	private String coomment;
	private Date dtSub;
	@ManyToOne
	@JoinColumn(name = "msgId")
	protected Message sourceMessage;
	@ManyToOne
	@JoinColumn(name = "email")
	private User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Integer getCommentId() {
		return commentId;
	}

	public void setCommentId(Integer commentId) {
		this.commentId = commentId;
	}

	public String getCoomment() {
		return coomment;
	}

	public void setCoomment(String coomment) {
		this.coomment = coomment;
	}
	@Temporal(TemporalType.TIMESTAMP)
	public Date getDtSub() {
		return dtSub;
	}

	public void setDtSub(Date dtSub) {
		this.dtSub = dtSub;
	}

	public Message getSourceMessage() {
		return sourceMessage;
	}

	public void setSourceMessage(Message sourceMessage) {
		this.sourceMessage = sourceMessage;
	}

	/*@Id
	@GenericGenerator(name="gen2",strategy="increment")
	@GeneratedValue(generator="gen2")
	private int commentId;
	@Column(name="comment")
	private String comment;
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtSub;
	
	@ManyToOne(targetEntity=User.class,
			cascade=CascadeType.ALL,
			fetch=FetchType.LAZY)
	@JoinColumn(name="userid",referencedColumnName="email")
	private User user;
	
	@ManyToOne(targetEntity=User.class,
			cascade=CascadeType.ALL,
			fetch=FetchType.LAZY)
	@JoinColumn(name="msgid",referencedColumnName="msgId")
	private Message msg;
	*//**
	 * @return the dtSub
	 *//*
	public Date getDtSub() {
		return dtSub;
	}
	*//**
	 * @param dtSub the dtSub to set
	 *//*
	public void setDtSub(Date dtSub) {
		this.dtSub = dtSub;
	}
	*//**
	 * @return the msg
	 *//*
	public Message getMsg() {
		return msg;
	}
	*//**
	 * @param msg the msg to set
	 *//*
	public void setMsg(Message msg) {
		this.msg = msg;
	}
	*//**
	 * @param user the user to set
	 *//*
	public void setUser(User user) {
		this.user = user;
	}
	*//**
	 * @return the commentId
	 *//*
	public int getCommentId() {
		return commentId;
	}
	*//**
	 * @param commentId the commentId to set
	 *//*
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	*//**
	 * @return the comment
	 *//*
	public String getComment() {
		return comment;
	}
	*//**
	 * @param comment the comment to set
	 *//*
	public void setComment(String comment) {
		this.comment = comment;
	}

	*//**
	 * @return the user
	 *//*
	public User getUser() {
		return user;
	}
	 (non-Javadoc)
	 * @see java.lang.Object#toString()
	 
	@Override
	public String toString() {
		return "Comment [commentId=" + commentId + ", comment=" + comment + ", user=" + user + "]";
	}
	*/
	
}
