/**
 * 
 */
package com.chart.bo;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author Parse
 *
 */
@Entity
@Table(name="user")
public class User implements Serializable{
	
	
	private String email;
	private String name;
	private String password;
	private Long mobile;
	private Set<Message> messages;
	private List<Comment> comments;
	
	@OneToMany(fetch=FetchType.EAGER)
	@JoinColumn(name = "email")
	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	@Id
	@Column(name = "email", length = 45)
	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "name", length = 45)
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "password", length = 45)
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name = "mobile")
	public Long getMobile() {
		return this.mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}
	@OneToMany
	@JoinColumn(name = "email")
	public Set<Message> getMessages() {
		return messages;
	}

	public void setMessages(Set<Message> messages) {
		this.messages = messages;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*@Id
	private String email;
	private String name;
	private String password;
	private Long mobile;
	
	Special property one user can give multiple message
	@OneToMany(targetEntity=Message.class,
			cascade=CascadeType.ALL,
			fetch=FetchType.LAZY,
			orphanRemoval=true)
	@JoinColumn(name="userid",referencedColumnName="email")
	@OrderColumn(name="sequence")
	private List<Message> msgs;
	
	Special property one user can give multiple comments
	@OneToMany(targetEntity=Comment.class)
	@JoinColumn(name="userid",referencedColumnName="email")
	@OrderColumn(name="sequence")
	private List<Comment> comments;
	
	*//**
	 * @return the email
	 *//*
	public String getEmail() {
		return email;
	}
	*//**
	 * @param email the email to set
	 *//*
	public void setEmail(String email) {
		this.email = email;
	}
	*//**
	 * @return the name
	 *//*
	public String getName() {
		return name;
	}
	*//**
	 * @param name the name to set
	 *//*
	public void setName(String name) {
		this.name = name;
	}
	*//**
	 * @return the password
	 *//*
	public String getPassword() {
		return password;
	}
	*//**
	 * @param password the password to set
	 *//*
	public void setPassword(String password) {
		this.password = password;
	}
	*//**
	 * @return the mobile
	 *//*
	public Long getMobile() {
		return mobile;
	}
	*//**
	 * @param mobile the mobile to set
	 *//*
	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}
	 (non-Javadoc)
	 * @see java.lang.Object#toString()
	 
	@Override
	public String toString() {
		return "User [email=" + email + ", name=" + name + ", password=" + password + ", mobile=" + mobile + "]";
	}
	
*/	
	

}
