/**
 * 
 */
package com.chart.bo;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Parse
 *
 */
@Entity
@Table
public class Message implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer msgId;
	@ManyToOne
	@JoinColumn(name = "email")
	private User user;
	private String message;
	private Date dtSub;
	@OneToMany
	@JoinColumn(name = "msgId")
	protected Set<Comment> comments;
	@Column(name="groupname")
	private String chartGroupName;

	/**
	 * @return the chartGroupName
	 */
	public String getChartGroupName() {
		return chartGroupName;
	}

	/**
	 * @param chartGroupName the chartGroupName to set
	 */
	public void setChartGroupName(String chartGroupName) {
		this.chartGroupName = chartGroupName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Message [msgId=" + msgId + ", user=" + user + ", message=" + message + ", dtSub=" + dtSub
				+ ", comments=" + comments + ", chartGroupName=" + chartGroupName + "]";
	}

	public Integer getMsgId() {
		return msgId;
	}

	public void setMsgId(Integer msgId) {
		this.msgId = msgId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	@Temporal(TemporalType.DATE)
	public Date getDtSub() {
		return dtSub;
	}

	public void setDtSub(Date dtSub) {
		this.dtSub = dtSub;
	}

	public Set<Comment> getComments() {
		return comments;
	}

	public void setComments(Set<Comment> comments) {
		this.comments = comments;
	}

	
	
	
	
	
	/*@Id
	@GenericGenerator(name="gen1",strategy="increment")
	@GeneratedValue(generator="gen1")
	private int msgId;
	@Column(name="message")
	private String message;
	@Temporal(TemporalType.TIMESTAMP)
	private Date dtSub;
	
	@ManyToOne(
			cascade=CascadeType.ALL,
			fetch=FetchType.LAZY)
	@JoinColumn(name="userid",referencedColumnName="email")
	private User user;
	
	@OneToMany(targetEntity=Comment.class,
			cascade=CascadeType.ALL,
			fetch=FetchType.LAZY,
			orphanRemoval=true)
	@JoinColumn(name="msgid",referencedColumnName="msgId")
	private List<Comment> comment;
	
	*//**
	 * @return the dtSub
	 *//*
	public Date getDtSub() {
		return dtSub;
	}
	*//**
	 * @param dtSub the dtSub to set
	 *//*
	public void setDtSub(Date dtSub) {
		this.dtSub = dtSub;
	}
	*//**
	 * @return the user
	 *//*
	public User getUser() {
		return user;
	}
	*//**
	 * @param user the user to set
	 *//*
	public void setUser(User user) {
		this.user = user;
	}
	
	*//**
	 * @return the msgId
	 *//*
	public int getMsgId() {
		return msgId;
	}
	*//**
	 * @param msgId the msgId to set
	 *//*
	public void setMsgId(int msgId) {
		this.msgId = msgId;
	}
	*//**
	 * @return the message
	 *//*
	public String getMessage() {
		return message;
	}
	*//**
	 * @param message the message to set
	 *//*
	public void setMessage(String message) {
		this.message = message;
	}

	*//**
	 * @return the comment
	 *//*
	
	*//**
	 * @param comment the comment to set
	 *//*
	public void setComment(List<Comment> comment) {
		this.comment = comment;
	}
	 (non-Javadoc)
	 * @see java.lang.Object#toString()
	 
	@Override
	public String toString() {
		return "Message [msgId=" + msgId + ", message=" + message + ", user=" + user + ", comment=" + comment + "]";
	}
*/	
	

}
